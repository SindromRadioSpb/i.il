import { describe, expect, it } from 'vitest';

describe('web smoke', () => {
  it('runs tests', () => {
    expect(true).toBe(true);
  });
});
